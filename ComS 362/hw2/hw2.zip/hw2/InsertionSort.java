package hw2;

public class InsertionSort implements Sortable{
	
	@Override
	public String getName() {
		return "insertion Sort";
	}

	@Override
	public int[] sort(int[] data) {
		EvalSorts.randomDelay();
		return data;
	}
}
