package hw2;

public class SelectionSort implements Sortable {
	
	@Override
	public String getName() {
		return "selection Sort";
	}

	@Override
	public int[] sort(int[] data) {
		EvalSorts.randomDelay();
		return data;
	}
}
