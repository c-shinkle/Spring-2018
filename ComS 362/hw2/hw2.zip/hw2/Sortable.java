package hw2;

public interface Sortable {
	public String getName();
	public int[] sort(int[] data);
}
