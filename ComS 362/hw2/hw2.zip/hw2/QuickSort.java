package hw2;

public class QuickSort implements Sortable {
	
	@Override
	public String getName() {
		return "quick Sort";
	}

	@Override
	public int[] sort(int[] data) {
		EvalSorts.randomDelay();
		return data;
	}
}
